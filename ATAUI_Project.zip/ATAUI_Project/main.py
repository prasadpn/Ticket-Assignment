import re
import string
import ftfy
from flask import Flask, render_template, request
from sklearn.preprocessing import LabelEncoder
import keras
from keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pandas as pd
#from textblob import TextBlob
#from langdetect import detect, detect_langs
#from deep_translator import GoogleTranslator
#from spellchecker import SpellChecker
#import contractions
from werkzeug import serving

app = Flask(__name__)


@app.route("/")
def home():
    # load_model()

    return render_template("home.html")


@app.route('/classify_ticket', methods=['GET', 'POST'])
def classify_ticket():
    # data_xls['Predicted Assignment Group']='GRP_0'
    data_xls['Description']= data_xls['Description'].apply(preprocess_text_part1)
    data_xls['Description'] = data_xls['Description'].apply(preprocess_text_part2)
    print(data_xls['Description'])
    prediction = load_model(data_xls['Description'])
    data_xls['Predicted Assignment Group'] = prediction

    return render_template("Prediction.html", column_names=data_xls.columns.values,
                           row_data=list(data_xls.values.tolist()),
                           zip=zip)


@app.route("/upload", methods=['GET', 'POST'])
def upload_file():
    global data_xls

    if request.method == 'POST':
        print(request.files['file'])
        f = request.files['file']
        data_xls = pd.read_excel(f)
        return render_template("home.html", column_names=data_xls.columns.values,
                               row_data=list(data_xls.values.tolist()), zip=zip)
        # x= jsonify({"result": request.get_array(field_name='file')})
        # return render_template("home.html", inputDF=x)

    return "null"


def load_model(df_predict):
    filename = "ATAModel/short_desc_model.h5"
    atamodel = keras.models.load_model(filename)
    print(atamodel)
    le = LabelEncoder()
    AssignGrouplist = ['GRP_38', 'GRP_35', 'GRP_37', 'GRP_10', 'GRP_31', 'GRP_43', 'GRP_13', 'GRP_5', 'GRP_40',
                       'GRP_63', 'GRP_50', 'GRP_23', 'GRP_57', 'GRP_3', 'GRP_42', 'GRP_21', 'GRP_51', 'GRP_18',
                       'GRP_68', 'GRP_6', 'GRP_71', 'GRP_27', 'GRP_36', 'GRP_44', 'GRP_2', 'GRP_9', 'GRP_60', 'GRP_64',
                       'GRP_8', 'GRP_53', 'GRP_19', 'GRP_20', 'GRP_69', 'GRP_7', 'GRP_17', 'GRP_14', 'GRP_72', 'GRP_22',
                       'GRP_55', 'GRP_49', 'GRP_65', 'GRP_11', 'GRP_28', 'GRP_39', 'GRP_1', 'GRP_52', 'GRP_54',
                       'GRP_73', 'GRP_61', 'GRP_47', 'GRP_16', 'GRP_0', 'GRP_48', 'GRP_62', 'GRP_33', 'GRP_26', 'GRP_4',
                       'GRP_46', 'GRP_34', 'GRP_41', 'GRP_56', 'GRP_29', 'GRP_24', 'GRP_25', 'GRP_32', 'GRP_67',
                       'GRP_59', 'GRP_15', 'GRP_45', 'GRP_30', 'GRP_12', 'GRP_66', 'GRP_70', 'GRP_58']

    le.fit_transform(AssignGrouplist)
    short_desc_max_words = 7000
    short_desc_length_to_filter = 150
    oov_tok = '<OOV>'
    short_desc_length_to_filter_input = 8  # int(0.3 * short_desc_length_to_filter)

    short_desc_sequences, short_desc_word_index = conv_text_to_sequences(short_desc_max_words, oov_tok,
                                                                         df_predict)
    short_desc_padded_sequences = padded_sequence(short_desc_sequences, short_desc_length_to_filter_input, 'post',
                                                  'post')
    predictedGroup = atamodel.predict(short_desc_padded_sequences)
    predlist = list(le.inverse_transform(predictedGroup.argmax(axis=1)))
    return predlist


def padded_sequence(sequences_input, length_to_filter_input, padding_input, truncat_input):
    padded_text_sequences = pad_sequences(sequences_input, maxlen=length_to_filter_input, padding=padding_input,
                                          truncating=truncat_input)
    return padded_text_sequences


def conv_text_to_sequences(max_words_input, oov_tok_input, data_input):
    tokenizer = Tokenizer(num_words=max_words_input, filters='!"#$%&()*+,-/.:;<=>?@[\\]^`{|}~\t\n', lower=True,
                          oov_token=oov_tok_input)
    tokenizer.fit_on_texts(data_input)
    word_index = tokenizer.word_index
    sequences = tokenizer.texts_to_sequences(data_input)
    return sequences, word_index


def clean_mojibake(text):
    cleaned_mojibake = ftfy.fix_text(text)
    return cleaned_mojibake


def convert_to_lowercase(text):
    return text.lower()


def preprocess_text_part1(text):
    text = clean_mojibake(text)
    text = convert_to_lowercase(text)
    return text



def remove_lead_trail_space(text):
    return text.strip()


def remove_punctuation(text):

    PUNCT_TO_REMOVE = string.punctuation
    return text.translate(str.maketrans('', '', PUNCT_TO_REMOVE))


def remove_received_from_mail(text):
    match = re.search(r'received from: [\w\.-]+@[\w\.-]+', text)
    if bool(match):
        text = text.replace(match.group(0), "")
    return text


def remove_linebreaks(text):
    text = text.replace("\r", " ")
    text = text.replace("\n", " ")
    text = text.replace("\t", " ")
    return text


def extract_subject_from_mail(text):
    return_subject = ""
    match_subject = re.search(r'subject:.*[\r\n\t\f\v]', text)
    if bool(match_subject):
        return_subject = match_subject.group(0).replace('subject:', "")
        return_subject = remove_linebreaks(return_subject)
        return_subject = remove_lead_trail_space(return_subject)
    else:
        return_subject = "No Match"
    return return_subject


def remove_greetings(text):
    match_greetings = re.search(r'(^|\s)(good day|good afternoon|good morning|good evening)(,|\s|!|.|:)', text)
    if bool(match_greetings):
        text = text.replace(match_greetings.group(0), "")
    return text


def remove_hello_wishes(text):
    match_hellowishes = re.search(
        r'(hello i.t. team|hello help-team|hello support team|hello help-team|hello it-team|hello ladies and gentlemen|hello  it helper|hellow|hello it support|hello all|hello colleagues|hi there|hello it team|hello sir|hello it service|hello it|hello helpdesk|hello team|hello all|hello it desk|hello  it helper|hello dac|hello|gentles|it team|dear all|dear it|dear|hallo|all groups|it help|team)(,|\s|!|.|:|;|<|~)',
        text)
    if bool(match_hellowishes):
        text = text.replace(match_hellowishes.group(0), "")
    return text


def remove_best_wishes(text):
    match_bestwishes = re.search(r'(with best|best|with kind|kind|many|with warm|warm)$', text)
    if bool(match_bestwishes):
        text = text.replace(match_bestwishes.group(0), "")
    return text


def remove_hi(text):
    match_hi = re.search(r'(hi it|hi team|hi it experts|hi)(,|\s|!|.|:)', text)
    if bool(match_hi):
        text = text.replace(match_hi.group(0), "")
    return text


def remove_thanking(text):
    match_thanking = re.search(r'(thanking you|thanking u|thank u|thank you|thanks)(,|.|/s|$)', text)
    if bool(match_thanking):
        text = text.replace(match_thanking.group(0), "")
    return text


def remove_digits(text):
    digits_rem = ''.join((x for x in text if not x.isdigit()))
    return digits_rem


def translate_to_english(text):
    translated_text = text
   # try:
       # if (detect(text) != 'en'):
         #   translated_text = GoogleTranslator(source='auto', target='english').translate(text)
   # except:
     #   translated_text = text
    return translated_text


def fix_contractions(text):
    #fixed_contractions = contractions.fix(text)
    return #fixed_contractions


def remove_please(text):
    match_help = re.search(r'please help to', text)
    if bool(match_help):
        text = text.replace(match_help.group(0), "")
    return text


def remove_email(text):
    matched_emails = re.findall('\S+@\S+', text)

    for email in matched_emails:
        text = text.replace(email, "")
    return text


def removed_from_to_sent_date(text):
    ## Removes the occurances of
    ## from: till any of the line breaks
    ## to: till any of the line breaks
    ## sent: till any of the line breaks
    ## date: till any of the line breaks
    ## cc: till any of the line breaks
    ## subject: till any of the line breaks
    ## importance: till any of the line breaks

    match_job_time = re.findall(r'at:.[0-9]+/[0-9]+/[0-9]+.[0-9]+:[0-9]+:[0-9]+', text)
    match_mailto = re.findall(r'<mailto:.*>', text)
    match_from = re.findall(r'from:.*[\r\n]', text)
    match_to = re.findall(r'to:.*[\r\n]', text)
    match_sent = re.findall(r'sent:.*[\r\n]', text)
    match_date = re.findall(r'date:.*[\r\n]', text)
    match_cc = re.findall(r'cc:.*[\r\n]', text)
    match_subject = re.findall(r'subject:.*[\r\n]', text)
    match_importance = re.findall(r'importance:.*[\r\n]', text)
    match_first_name = re.findall(r'first name.*[\r\n]', text)
    match_last_name = re.findall(r'last name.*[\r\n]', text)
    match_user_name_space = re.findall(r'user name:.*[\r\n]', text)
    match_user_name = re.findall(r'username:.*[\r\n]', text)
    match_name = re.findall(r'name:.*[\r\n]', text)
    match_language = re.findall(r'language:.*[\r\n]', text)
    match_browser = re.findall(r'browser:.*[\r\n]', text)
    match_mail_id = re.findall(r'mail id:.*[\r\n]', text)
    match_email_address = re.findall(r'email address:.*[\r\n]', text)
    match_email = re.findall(r'email:.*[\r\n]', text)
    match_customernumber = re.findall(r'customer number:.*[\r\n]', text)
    match_customerjobtitle = re.findall(r'customer job title:.*[\r\n]', text)
    match_telephone = re.findall(r'telephone:.*[\r\n]', text)
    match_contact = re.findall(r'contact #:.*[\r\n]', text)
    match_vit_ref_num = re.findall(r'vitalyst reference number:.*[\r\n]', text)
    match_supervisor = re.findall(r'supervisor:.*[\r\n]', text)
    match_manager = re.findall(r'manager.*[\r\n]', text)
    match_i_number = re.findall(r'i number:.*[\r\n]', text)
    match_cost_center = re.findall(r'cost center.*[\r\n]', text)
    match_ext_comp = re.findall(r'external company name.*[\r\n]', text)
    match_emp_id = re.findall(r'emp id:.*[\r\n]', text)
    match_emb_image = re.findall(r'\[cid:image.*\]', text)
    match_begin_fwd_msg = re.findall(r'begin forwarded message:', text)
    match_sent_from_iphone = re.findall(r'(sent from my iphone|sent from my ipad)', text)
    match_sir_madam = re.findall(r'(sir or madam,|sir/mam,|sir,)', text)
    match_yes_no_na_option = re.findall(r'(\(yes/no/na\))', text)
    match_summary = re.findall(r'summary:', text)

    all_matches = match_job_time + match_mailto + match_from + match_to + match_sent + match_date + match_cc + match_subject + match_importance + match_first_name + match_last_name + match_user_name_space + match_user_name + match_name + match_language + match_browser + match_mail_id + match_email_address + match_email + match_customernumber + match_telephone + match_summary + match_customerjobtitle + match_contact + match_vit_ref_num + match_supervisor + match_manager + match_i_number + match_cost_center + match_ext_comp + match_emp_id + match_emb_image + match_begin_fwd_msg + match_sent_from_iphone + match_sir_madam + match_yes_no_na_option

    for matched_text in all_matches:
        text = text.replace(matched_text, "")

    return text


def expand_pls(text):
    match_pls = re.search(r'(pls)(\s|.)', text)
    if bool(match_pls):
        text = text.replace(match_pls.group(0), "")
    return text


def preprocess_text_part2(text):
    text = remove_received_from_mail(text)
    text = remove_email(text)
    text = removed_from_to_sent_date(text)
    text = remove_linebreaks(text)
    text = remove_lead_trail_space(text)
   # text = translate_to_english(text)
    text = remove_punctuation(text)
    text = remove_digits(text)
    text = remove_greetings(text)
    text = remove_best_wishes(text)
    text = remove_hello_wishes(text)
    # text = remove_stopwords(text)
    # text = lemmetize_text(text)
    text = remove_hello_wishes(text)
    text = remove_lead_trail_space(text)
    text = remove_hi(text)
    text = remove_thanking(text)
    text = expand_pls(text)
    text = remove_please(text)
    #text = fix_contractions(text)
    text = remove_lead_trail_space(text)
    return text
